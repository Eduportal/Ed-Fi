﻿namespace $safeprojectname$
{
    // TODO: Rename this interface to match the marker interface convention
    public interface Marker_EdFi_Ods_Api_CustomProfiles { }
}
